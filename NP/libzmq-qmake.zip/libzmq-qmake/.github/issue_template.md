*Please use this template for reporting suspected bugs or requests for help.*

# Issue description



# Environment

* libzmq version (commit hash if unreleased): 
* OS: 

# Minimal test code / Steps to reproduce the issue

1.  


# What's the actual result? (include assertion message & call stack if applicable)



# What's the expected result?

