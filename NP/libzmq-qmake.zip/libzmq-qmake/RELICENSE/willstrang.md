# Permission to Relicense under MPLv2 or any other OSI approved license chosen by the current ZeroMQ BDFL

This is a statement by William P Strang
that grants permission to relicense its copyrights in the libzmq C++
library (ZeroMQ) under the Mozilla Public License v2 (MPLv2) or any other 
Open Source Initiative approved license chosen by the current ZeroMQ 
BDFL (Benevolent Dictator for Life).

A portion of the commits made by the Github handle "willstrang", with
commit author "Will Strang <william.p.strang@gmail.com", are copyright of William P Strang.
This document hereby grants the libzmq project team to relicense libzmq, 
including all past, present and future contributions of the author listed above.

William P Strang  
2017/03/23
