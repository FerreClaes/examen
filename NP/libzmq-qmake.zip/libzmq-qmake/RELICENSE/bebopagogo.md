# Permission to Relicense under MPLv2

This is a statement by Brian Adamson that grants permission to relicense its
copyrights in the libzmq C++ library (ZeroMQ) under the Mozilla Public License v2
(MPLv2).

A portion of the commits made by the Github handle "bebopagogo", with commit
author "bebopagogo <bebopagogo@users.noreply.github.com>" and "Brian Adamson
<badamson@gmail.com>", are copyright of Brian Adamson. This document hereby grants
the libzmq project team to relicense libzmq, including all past, present and
future contributions of the author listed above.

Brian Adamson 2019/08/11 s
